## Usage

```bash
curl -s https://raw.githubusercontent.com/DengekiBunko/vls/refs/heads/main/lunes-host/install.sh |
env DOMAIN=node68.lunes.host PORT=3147 UUID=2584b733-9095-4bec-a7d5-62b473540f7a HY2_PASSWORD='vevc.HY2.Password' bash
```
