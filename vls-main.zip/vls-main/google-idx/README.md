## Usage

```bash
export PORT=8080 UUID=2584b733-9095-4bec-a7d5-62b473540f7a
curl -sSL https://raw.githubusercontent.com/vevc/one-node/refs/heads/main/google-idx/install.sh | sh
```
